from django.shortcuts import render,redirect
from .models import Timesheets_mng,AppraisalMngSystem,Employee
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login
from django.http import HttpResponse

# Create your views here.

def createuser(request):
    if request.method == 'POST':
        usern = request.POST.get("username")
        passw = request.POST.get("password")
        a = User.objects.create_user(username = usern,password = passw,is_staff = True, is_active = True, is_superuser = True)
        a.save()
    else:
        return render(request,"adminlog.html",context={})   
    return redirect("Abhi6")  

def cont(request):
      return render(request,"linking1.html",context={})

def emp(request):
    if request.method == 'POST':
        name = request.POST.get("name")
        address = request.POST.get("address")
        empID = request.POST.get("empID")
        b = Employee(name,address,empID)
        b.save()
    else:
        return render(request,"manage_emp.html",context={})   
    return redirect("Abhi6") 

def timesheet(request):
    if request.method == 'POST':
        emp_id = request.POST.get("empID")
        d = request.POST.get("day")
        da = request.POST.get("date")
        t_in = request.POST.get("timein")
        t_out = request.POST.get("timeout")
        t_hours = request.POST.get("totalhours")
        dept_ID = request.POST.get("deptID")
        c = Timesheets_mng(empID=emp_id,day=d,date=da,timein=t_in,timeout=t_out,totalhours=t_hours,deptID=dept_ID)
        c.save()
    else:
        return render(request,"tsheet.html",context={})    
    return redirect("Abhi6") 

def appraisal(request):
    if request.method == 'POST':
        empid = request.POST.get("emp_ID")
        jobknow = request.POST.get("jobknowledge")
        workq = request.POST.get("workquality")
        techs = request.POST.get("techskills")
        sal = request.POST.get("salary")
        app = request.POST.get("appraise")
        d = AppraisalMngSystem(emp_ID=empid,jobknowledge=jobknow,workquality = workq,techskills=techs,salary=sal,appraise=app)
        d.save()
    else:
        return render(request,"appraisal.html",context={})       
    return redirect("Abhi6") 

def adminlogin(request):
    if request.method == 'POST':
        usern = request.POST.get("username")
        passw = request.POST.get("password")
        a = User.objects.create_user(username = usern,password = passw,is_staff = True, is_active = True, is_superuser = True)
        a = a.save()
        userObj=User.objects.get(username=usern)
        if userObj is not None:
            user1=authenticate(request,username=usern,password=passw)
            print("user Found")
            if user1 is not None:
                login(request,user1)
            else:
                return HttpResponse("Auth failed")
        else:
            return redirect("Abhi1")
    else:
        return render(request,"loginform.html",context={})
    return redirect("Abhi6")

def emprep(request):
    e_rep = Employee.objects.all()
    #print(e_rep)
    return render(request,"emprep.html",context={"e_rep":e_rep})

def t_sheet_rep(request):
    t_rep = Timesheets_mng.objects.all()
    #print(e_rep)
    return render(request,"trep.html",context={"t_rep":t_rep})

def app_rep(request):
    app_rep = AppraisalMngSystem.objects.all()
    #print(e_rep)
    return render(request,"appreport.html",context={"app_rep":app_rep})

def list_dept(request):
    l_dept = Timesheets_mng.objects.all()
    return render(request,"deptlist.html",context={"l_dept":l_dept})

def filter_dept1(request):
    f_dept1 = Timesheets_mng.objects.filter(deptID__istartswith=1)
    if f_dept1:
         return render(request,"dept1.html",context={"f_dept1":f_dept1})
    
def filter_dept2(request):
    f_dept2 = Timesheets_mng.objects.filter(deptID__istartswith=2)
    if f_dept2:
         return render(request,"dept2.html",context={"f_dept2":f_dept2})
         
def filter_dept3(request):
    f_dept3 = Timesheets_mng.objects.filter(deptID__istartswith=3)
    if f_dept3:
         return render(request,"dept3.html",context={"f_dept3":f_dept3})

def filter_dept4(request):
    f_dept4 = Timesheets_mng.objects.filter(deptID__istartswith=4)
    if f_dept4:
         return render(request,"dept4.html",context={"f_dept4":f_dept4})
    

