from emp_mg_sys import views
from django.urls import URLPattern, path

urlpatterns = [
    path('createadmin/',views.createuser,name="Abhi1"),
    path('empmng/',views.emp,name="Abhi2"),
    path('timesheet/',views.timesheet,name="Abhi3"),
    path('appraise/',views.appraisal,name="Abhi4"),
    path('emprep/',views.emprep,name="Abhi5"),
    path('welcome/',views.cont,name="Abhi6"),
    path('timerep/',views.t_sheet_rep,name="Abhi7"),
    path('apprep/',views.app_rep,name="Abhi8"),
    path('deptlist/',views.list_dept,name="Abhi9"),
    path('ftime1/',views.filter_dept1,name="Abhi10"),
    path('ftime2/',views.filter_dept2,name="Abhi11"),
    path('ftime3/',views.filter_dept3,name="Abhi12"),
    path('ftime4/',views.filter_dept4,name="Abhi13"),
    path('adminlog/',views.adminlogin,name="Abhi14")
    
]